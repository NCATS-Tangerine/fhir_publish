// Copyright (c) 2011+, HL7, Inc & The MITRE Corporation
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
// 
//     * Redistributions of source code must retain the above copyright notice, this 
//       list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright notice, 
//       this list of conditions and the following disclaimer in the documentation 
//       and/or other materials provided with the distribution.
//     * Neither the name of HL7 nor the names of its contributors may be used to 
//       endorse or promote products derived from this software without specific 
//       prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
// POSSIBILITY OF SUCH DAMAGE.

var mongoose = require('mongoose');

var SubstanceSpecificationSchema = new mongoose.Schema({
    comment: String,
    stoichiometric: Boolean,
    identifier: {
        use: String,
        label: String,
        system: String,
        value: String
    },
    fhirType: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    referenceSource: String,
    moiety: [{
        role: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        identifier: {
            use: String,
            label: String,
            system: String,
            value: String
        },
        name: String,
        stereochemistry: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        opticalActivity: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        molecularFormula: String,
        amount: String,
    }],
    property: [{
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        name: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        parameters: String,
        substanceId: {
            use: String,
            label: String,
            system: String,
            value: String
        },
        substanceName: String,
        amount: String,
    }],
    referenceInformation: {
    },
    structure: {
        stereochemistry: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        opticalActivity: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        molecularFormula: String,
        molecularFormulaByMoiety: String,
        isotope: [{
            nuclideId: {
                use: String,
                label: String,
                system: String,
                value: String
            },
            nuclideName: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            substitutionType: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            nuclideHalfLife: {
                value: String,
                units: String,
                system: String,
                code: String
            },
            amount: String,
            molecularWeight: {
                method: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                },
                fhirType: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                },
                amount: String,
            }
        }],
        molecularWeight: {
        },
        referenceSource: [{
        }],
        structuralRepresentation: [{
            fhirType: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            representation: String,
            attachment: {
            }
        }]
    },
    substanceCode: [{
        code: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        status: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        statusDate: Date,
        comment: String,
        referenceSource: String,
    }],
    substanceName: [{
        name: String,
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        language: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        domain: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        jurisdiction: [{
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        officialName: [{
            authority: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            status: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            date: Date,
        }],
        referenceSource: String,
    }],
    molecularWeight: [{
    }],
    polymer: {
    }
});

mongoose.model('SubstanceSpecification', SubstanceSpecificationSchema);
