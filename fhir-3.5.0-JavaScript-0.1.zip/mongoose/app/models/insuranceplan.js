// Copyright (c) 2011+, HL7, Inc & The MITRE Corporation
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
// 
//     * Redistributions of source code must retain the above copyright notice, this 
//       list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright notice, 
//       this list of conditions and the following disclaimer in the documentation 
//       and/or other materials provided with the distribution.
//     * Neither the name of HL7 nor the names of its contributors may be used to 
//       endorse or promote products derived from this software without specific 
//       prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
// POSSIBILITY OF SUCH DAMAGE.

var mongoose = require('mongoose');

var InsurancePlanSchema = new mongoose.Schema({
    identifier: [{
        use: String,
        label: String,
        system: String,
        value: String
    }],
    status: String,
    fhirType: [{
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    }],
    name: String,
    alias: String,
    period: {
    },
    ownedBy: {
    },
    administeredBy: {
    },
    coverageArea: [{
    }],
    contact: [{
        purpose: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        name: {
            use: String,
            text: String,
            family: [String],
            given: [String],
            prefix: [String],
            suffix: [String]
        },
        telecom: [{
        }],
        address: {
        }
    }],
    endpoint: [{
    }],
    network: [{
    }],
    coverage: [{
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        network: [{
        }],
        benefit: [{
            fhirType: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            requirement: String,
            limit: [{
                value: {
                    value: String,
                    units: String,
                    system: String,
                    code: String
                },
                code: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                }
            }]
        }]
    }],
    plan: [{
        identifier: [{
            use: String,
            label: String,
            system: String,
            value: String
        }],
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        coverageArea: [{
        }],
        network: [{
        }],
        generalCost: [{
            fhirType: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            groupSize: {
            },
            cost: {
            },
            comment: String,
        }],
        specificCost: [{
            category: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            benefit: [{
                fhirType: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                },
                cost: [{
                    fhirType: {
                        coding: [{
                            system: String,
                            code: String,
                            display: String
                        }]
                    },
                    applicability: {
                        coding: [{
                            system: String,
                            code: String,
                            display: String
                        }]
                    },
                    qualifiers: [{
                        coding: [{
                            system: String,
                            code: String,
                            display: String
                        }]
                    }],
                    value: {
                        value: String,
                        units: String,
                        system: String,
                        code: String
                    }
                }]
            }]
        }]
    }]
});

mongoose.model('InsurancePlan', InsurancePlanSchema);
