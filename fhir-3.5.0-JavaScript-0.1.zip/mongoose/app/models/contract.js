// Copyright (c) 2011+, HL7, Inc & The MITRE Corporation
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without modification, 
// are permitted provided that the following conditions are met:
// 
//     * Redistributions of source code must retain the above copyright notice, this 
//       list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright notice, 
//       this list of conditions and the following disclaimer in the documentation 
//       and/or other materials provided with the distribution.
//     * Neither the name of HL7 nor the names of its contributors may be used to 
//       endorse or promote products derived from this software without specific 
//       prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
// NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
// POSSIBILITY OF SUCH DAMAGE.

var mongoose = require('mongoose');

var ContractSchema = new mongoose.Schema({
    identifier: [{
        use: String,
        label: String,
        system: String,
        value: String
    }],
    url: String,
    version: String,
    status: String,
    legalState: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    instantiatesCanonical: {
    },
    instantiatesUri: String,
    contentDerivative: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    issued: Date,
    applies: {
    },
    expirationType: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    subject: [{
    }],
    authority: [{
    }],
    domain: [{
    }],
    site: [{
    }],
    name: String,
    title: String,
    subtitle: String,
    alias: String,
    author: {
    },
    scope: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    topicCodeableConcept: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    topicReference: {
    },
    fhirType: {
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    },
    subType: [{
        coding: [{
            system: String,
            code: String,
            display: String
        }]
    }],
    contentDefinition: {
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        subType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        publisher: {
        },
        publicationDate: Date,
        publicationStatus: String,
        copyright: {
        }
    },
    term: [{
        identifier: {
            use: String,
            label: String,
            system: String,
            value: String
        },
        issued: Date,
        applies: {
        },
        topicCodeableConcept: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        topicReference: {
        },
        fhirType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        subType: {
            coding: [{
                system: String,
                code: String,
                display: String
            }]
        },
        text: String,
        securityLabel: [{
            number: [{
            }],
            classification: {
                system: String,
                code: String,
                display: String
            },
            category: [{
                system: String,
                code: String,
                display: String
            }],
            control: [{
                system: String,
                code: String,
                display: String
            }]
        }],
        offer: {
            identifier: [{
                use: String,
                label: String,
                system: String,
                value: String
            }],
            party: [{
                reference: [{
                }],
                role: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                }
            }],
            topic: {
            },
            fhirType: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            decision: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            decisionMode: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            answer: [{
                valueBoolean: Boolean,
                valueDecimal: Number,
                valueInteger: Number,
                valueDate: Date,
                valueDateTime: Date,
                valueTime: {
                },
                valueString: String,
                valueUri: String,
                valueAttachment: {
                },
                valueCoding: {
                    system: String,
                    code: String,
                    display: String
                },
                valueQuantity: {
                    value: String,
                    units: String,
                    system: String,
                    code: String
                },
                valueReference: {
                }
            }],
            text: String,
            linkId: String,
            securityLabelNumber: [{
            }]
        },
        asset: [{
            scope: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            fhirType: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            typeReference: [{
            }],
            subtype: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            relationship: {
                system: String,
                code: String,
                display: String
            },
            context: [{
                reference: {
                },
                code: [{
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                }],
                text: String,
            }],
            condition: String,
            periodType: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            period: [{
            }],
            usePeriod: [{
            }],
            text: String,
            linkId: String,
            answer: [{
            }],
            securityLabelNumber: [{
            }],
            valuedItem: [{
                entityCodeableConcept: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                },
                entityReference: {
                },
                identifier: {
                    use: String,
                    label: String,
                    system: String,
                    value: String
                },
                effectiveTime: Date,
                quantity: {
                },
                unitPrice: {
                },
                factor: Number,
                points: Number,
                net: {
                },
                payment: String,
                paymentDate: Date,
                responsible: {
                },
                recipient: {
                },
                linkId: String,
                securityLabelNumber: [{
                }]
            }]
        }],
        action: [{
            doNotPerform: Boolean,
            fhirType: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            subject: [{
                reference: [{
                }],
                role: {
                    coding: [{
                        system: String,
                        code: String,
                        display: String
                    }]
                }
            }],
            intent: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            linkId: String,
            status: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            context: {
            },
            contextLinkId: String,
            occurrenceDateTime: Date,
            occurrencePeriod: {
            },
            occurrenceTiming: {
            },
            requester: [{
            }],
            requesterLinkId: String,
            performerType: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            performerRole: {
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            },
            performer: {
            },
            performerLinkId: String,
            reasonCode: [{
                coding: [{
                    system: String,
                    code: String,
                    display: String
                }]
            }],
            reasonReference: [{
            }],
            reason: String,
            reasonLinkId: String,
            note: [{
            }],
            securityLabelNumber: [{
            }]
        }],
        group: [{
        }]
    }],
    supportingInfo: [{
    }],
    relevantHistory: [{
    }],
    signer: [{
        fhirType: {
            system: String,
            code: String,
            display: String
        },
        party: {
        },
        signature: [{
        }]
    }],
    friendly: [{
        contentAttachment: {
        },
        contentReference: {
        }
    }],
    legal: [{
        contentAttachment: {
        },
        contentReference: {
        }
    }],
    rule: [{
        contentAttachment: {
        },
        contentReference: {
        }
    }],
    legallyBindingAttachment: {
    },
    legallyBindingReference: {
    }
});

mongoose.model('Contract', ContractSchema);
